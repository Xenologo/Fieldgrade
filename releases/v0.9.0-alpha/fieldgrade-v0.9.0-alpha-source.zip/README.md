# Fieldgrade

[![CI](https://github.com/Xenologo/Fieldgrade/actions/workflows/ci.yml/badge.svg)](https://github.com/Xenologo/Fieldgrade/actions/workflows/ci.yml)
[![Latest Release](https://img.shields.io/github/v/release/Xenologo/Fieldgrade?display_name=tag)](https://github.com/Xenologo/Fieldgrade/releases)
[![License](https://img.shields.io/github/license/Xenologo/Fieldgrade)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)

**Evidence governance for audit-ready technical work.** Fieldgrade helps teams capture files, seal provenance, review decisions, govern AI-assisted work, and export proof packs without deploying a heavyweight ERP or QMS.

> **Capture evidence. Seal provenance. Review decisions. Export audit-ready proof.**

## Fieldgrade public doctrine

> **Show the proof layer. Occlude the complexity layer.**

Fieldgrade should publicly appear as a calm, practical evidence-governance product. Buyers should first see evidence capture, provenance, review, export, accountable AI-use, and local control. Internal kernels, graph analysis, and advanced architecture stay available, but they belong in advanced documentation rather than the first-touch product surface.

## Fieldgrade Phase 2 — Pilot Release and ProofOps Commercialisation

> Convert Fieldgrade from an alpha-grade evidence-governance repo into a founder-led pilot product with release artifacts, reproducible installation, proof-pack demos, setup intake, and first paid ProofOps packaging.

This phase is about making one person able to install Fieldgrade, understand the value, load a sample workflow, export a proof pack, and request a paid setup.

## Public product family

Fieldgrade is structured as a family of evidence-governance products:

- **Fieldgrade Core** — the evidence and provenance engine beneath the product family
- **Fieldgrade ProofOps** — turn messy operational evidence into reviewable, exportable proof
- **Fieldgrade GovAI** — govern AI-assisted work with evidence, review, and accountability
- **Fieldgrade FoodQA** — audit-ready evidence control for food, beverage, QA, and production teams

## Public-facing materials in this repository

- Landing page: [`/site/landing.html`](site/landing.html)
- Product pages: [`/site/products/`](site/products/)
- Demo page: [`/site/demo/index.html`](site/demo/index.html)
- Public docs page: [`/site/docs/index.html`](site/docs/index.html)
- Security and responsible AI-use page: [`/site/security/index.html`](site/security/index.html)
- Pilot setup page: [`/site/setup/index.html`](site/setup/index.html)
- Contact and pilot request page: [`/site/contact/index.html`](site/contact/index.html)
- Pricing and setup page: [`/site/pricing/index.html`](site/pricing/index.html)
- Sample deliverables: [`/exports`](exports)
- Release packet: [`/releases/v0.9.0-alpha`](releases/v0.9.0-alpha)

## Release-hardening documents

- [`LICENSE`](LICENSE)
- [`SECURITY.md`](SECURITY.md)
- [`INSTALL.md`](INSTALL.md)
- [`CHANGELOG.md`](CHANGELOG.md)
- [`DATA_HANDLING.md`](DATA_HANDLING.md)
- [`RELEASE_CHECKLIST.md`](RELEASE_CHECKLIST.md)
- [`RELEASE_NOTES_v0.9.0-alpha.md`](RELEASE_NOTES_v0.9.0-alpha.md)
- [`docs/FIELDGRADE_PHASE2_PILOT_RELEASE.md`](docs/FIELDGRADE_PHASE2_PILOT_RELEASE.md)

## What buyers should see first

Fieldgrade publicly emphasizes:

- evidence capture
- provenance sealing
- review workflow
- audit pack export
- AI accountability
- local-first governance

Fieldgrade publicly avoids over-claiming:

- it is **not** a full ERP
- it is **not** a full QMS
- it does **not** ask buyers to trust AI automatically
- it does **not** claim legally binding or regulator-approved decisions by default

## Initial offer

**Fieldgrade ProofOps Setup** is the recommended first paid offer:

- **£750 starting package**
- local installation
- branded workspace
- one demo dataset
- one export template
- one workflow pack such as FoodQA or GovAI
- one guided training session

## Public trust notes

- Fieldgrade separates capture, analysis, review, and approval.
- Evidence may be ingested automatically, but authority remains explicit.
- Sensitive evidence should not need to leave your machine just to become organised.
- AI output is never silently treated as truth.
- Fieldgrade supports evidence governance and audit preparation; it does not itself certify compliance or replace qualified auditors, QA managers, regulators, or responsible persons.
- Fieldgrade does not provide legal advice, and AI-assisted outputs require human review before operational or compliance decisions.

## Pilot setup and contact path

- Founder-led setup page: [`site/setup/index.html`](site/setup/index.html)
- Contact and pilot request page: [`site/contact/index.html`](site/contact/index.html)
- Structured intake form: [GitHub Issue template](https://github.com/Xenologo/Fieldgrade/issues/new?template=fieldgrade_pilot_request.yml)
- Starting commercial package: **Fieldgrade ProofOps Setup — £750 starting package**
- Suggested scope: local install, branded workspace, one workflow pack, one export template, one demo dataset, and one guided training session

## Release install mode vs development mode

### Pilot release install mode

Use pinned artifacts when you are evaluating or deploying the alpha:

- `uv lock`
- `uv.lock`
- `requirements.lock`
- `releases/v0.9.0-alpha/`

Recommended commands:

**Linux / WSL**

```bash
python3 -m pip install -U uv
uv sync --frozen
```

**Windows PowerShell**

```powershell
python -m pip install -U uv
uv sync --frozen
```

### Development mode

Use the bootstrap scripts when you want the editable workspace plus dev tools:

- `bash scripts/bootstrap_dev.sh`
- `.\scripts\bootstrap_dev.ps1`

## Repository architecture and advanced internals

This monorepo still carries the deeper substrate behind the public product surface:

- `termite_fieldpack/` is the evidence and provenance kernel
- `mite_ecology/` is the review and analysis kernel
- `fieldgrade_ui/` is the governance workspace and application shell

If you want the implementation depth, use the repository docs under `/docs`, especially architecture and deployment materials. The public site should not require buyers to understand those internals before they see value.

## Why this repository is technically credible

This monorepo already implements the audit substrate behind the public positioning:

- file ingestion into **content-addressed storage**
- **SQLite + FTS5** search
- **hash-chained provenance** events
- deterministic signed bundles
- replay verification
- local UI
- local/OpenAI-compatible LLM runtime ownership
- strict deterministic mode

# Technical overview

This monorepo provides:

## Fieldgrade UI: API quick reference

**Registry catalogs (current naming)**

- The versioned JSON Schemas live under `schemas/`:
   - `registry_components_v1.json`, `registry_variants_v1.json`, `registry_remotes_v1.json`
- The UI/API refers to these as **registries** (not `component_catalog_v1`).
- HTTP endpoints (return the registry payload + a deterministic `canonical_sha256`):
   - `GET /api/registry/components`
   - `GET /api/registry/variants`
   - `GET /api/registry/remotes`

**Knowledge graph query surface (current)**

- Today, the supported HTTP query surface is the lightweight `/api/graph/*` endpoints:
   - `GET /api/graph/nodes?filter=<substring>&limit=<n>`
   - `GET /api/graph/neighborhood?node_id=<id>&limit_edges=<n>`
- There is intentionally no general-purpose `/api/kg/*` surface yet.

## Canonical dev setup (recommended)

Use the bootstrap scripts to get to a known-good environment (runtime + dev deps + editable installs).

**Linux / WSL (bash):**

```bash
bash scripts/bootstrap_dev.sh
make test
```

**Windows (PowerShell):**

```powershell
.\scripts\bootstrap_dev.ps1
python -m pytest -q
```

After bootstrapping, you can run the CLIs (`termite`, `mite-ecology`, `fieldgrade-ui`) or follow the fast-start flows below.

### Warnings policy

Pytest is configured to treat `DeprecationWarning` and `PendingDeprecationWarning` as errors (CI gate).
If a new dependency or change introduces these warnings, fix or isolate it before merging.

## 1) `termite_fieldpack/` (Termux/field/offline)
A fieldable toolchain that can:

- **Ingest** files into a **CAS** (content-addressed blobs) + **SQLite** + **FTS5** (when available)
- Emit **hash-chained provenance** events (append-only)
- Store KG delta ops (`kg_delta.jsonl`) describing observed nodes/edges
- **Seal** deterministic, signed bundles (manifest + SBOM + provenance + kg_delta + blobs)
- **Verify** bundles against **MEAP v1** policy + toolchain allowlist
- **Replay** bundles conservatively (structural checks only; no tool re-exec)

## 2) `mite_ecology/` (design-time)
A minimal-but-real pipeline:

- Import verified termite bundles and apply `kg_delta.jsonl` to the KG
- Compute **deterministic GNN embeddings** via message passing (CPU / NumPy)
- Compute **deterministic GAT-style attention** over edges for a chosen context node
- Mine motifs from top-attention edges
- Run a **memoized deterministic GA** to evolve motif-derived genomes
- Export a minimal **neuroarch DSL** JSON + a tiny python skeleton

## Termite-owned local LLM runtime (optional but recommended)

Termite can **own the runtime identity** of your local OpenAI-compatible endpoint (llama.cpp server / vLLM / etc.).

- Configure `termite_fieldpack/config/termite.yaml` → `llm.*`
- Start / stop / ping via:

```bash
cd termite_fieldpack
./bin/termite llm status --json
./bin/termite llm ping
./bin/termite llm start        # launches if llm.launch.enabled=true, otherwise "marks active" after ping
./bin/termite llm stop
```

When `mite_ecology/configs/ecology.yaml` sets `llm.endpoint_source: termite`, the `mite-ecology llm-*` commands will query Termite for the active endpoint (base_url, model, endpoint_id, toolchain_id) and record this binding in the `llm_calls.request_json` audit record.

---

## Fast start (Linux / Termux-like)

```bash
# One-time setup
bash scripts/bootstrap_dev.sh

# (or manual setup)
# python -m venv .venv
# . .venv/bin/activate
# pip install -r termite_fieldpack/requirements.txt
# pip install -r mite_ecology/requirements.txt
# pip install -e termite_fieldpack
# pip install -e mite_ecology

# Termite runtime
cd termite_fieldpack
./bin/termite init
./bin/termite ingest ../README.md
./bin/termite search "field"
BUNDLE=$(./bin/termite seal --label demo)

./bin/termite verify "$BUNDLE"
./bin/termite replay "$BUNDLE"

# mite_ecology: import + embed + attention + motifs + GA + export
cd ../mite_ecology
./bin/mite-ecology init
./bin/mite-ecology import-bundle "$BUNDLE"
./bin/mite-ecology gnn
./bin/mite-ecology gat
./bin/mite-ecology motifs
./bin/mite-ecology ga
./bin/mite-ecology export
```

Outputs appear under:
- termite bundles: `termite_fieldpack/artifacts/bundles_out/`
- mite_ecology exports: `mite_ecology/artifacts/export/`

---

## Fast start (Windows / PowerShell)

```powershell
# One-time setup
.\scripts\bootstrap_dev.ps1

# (or manual setup)
# python -m venv .venv
# .\.venv\Scripts\Activate.ps1
# pip install -r termite_fieldpack\requirements.txt
# pip install -r mite_ecology\requirements.txt
# pip install -e termite_fieldpack
# pip install -e mite_ecology

# (Optional) confirm entrypoints
Get-Command termite
Get-Command mite-ecology

# Termite runtime
cd termite_fieldpack
python -m termite.cli init
python -m termite.cli ingest ..\README.md
$BUNDLE = (python -m termite.cli seal --label demo).Trim()
python -m termite.cli verify $BUNDLE
python -m termite.cli replay $BUNDLE

# mite_ecology: import + embed + attention + motifs + GA + export
cd ..\mite_ecology
python -m mite_ecology.cli init
python -m mite_ecology.cli import-bundle $BUNDLE
python -m mite_ecology.cli gnn
python -m mite_ecology.cli gat
python -m mite_ecology.cli motifs
python -m mite_ecology.cli ga
python -m mite_ecology.cli export
```

Or run everything in one command:

```powershell
.\run_demo.ps1
```

## Notes
- No heavy ML deps (no torch); everything is CPU + deterministic NumPy.
- The MEAP policy is in `termite_fieldpack/config/meap_v1.yaml`.
- Signature keys are generated into `termite_fieldpack/runtime/keys/` on first `termite init`.

## Platform guides

- Android (Termux): see `TERMUX.md`
- Windows laptop guide — see `WINDOWS.md` (WSL2 recommended)

## Deployment (Docker Compose)

This repo uses Docker Compose file stacking for dev vs production.

- Local dev (exposes `http://127.0.0.1:8787` directly):
   - `docker compose -f compose.yaml -f compose.dev.yaml up -d --build`

- Single-host production (Caddy TLS termination; do not expose `8787` directly):
    - `docker compose -f compose.yaml -f compose.production.yaml up -d --build`
    - See `docs/DEPLOY_PROD_SINGLEHOST.md` and `docs/DEPLOY_CHECKLIST.md`.

### Docker Compose smoke test

For a local smoke test with the development overlay:

```bash
export FG_API_TOKEN=demo-local-token
docker compose -f compose.yaml -f compose.dev.yaml up -d --build
curl -H "X-API-Key: ${FG_API_TOKEN}" http://127.0.0.1:8787/healthz
# For a first-run stack, initialize the readiness DB once as shown in INSTALL.md.
curl -H "X-API-Key: ${FG_API_TOKEN}" http://127.0.0.1:8787/readyz
docker compose -f compose.yaml -f compose.dev.yaml down
```

`/readyz` is intentionally conservative and stays unhealthy until the required runtime DBs exist.
Record the outcome in release notes before publishing a pilot build.

For production proxy header trust, prefer trusting only the Docker network CIDR (instead of `*`):

- Bring the stack up once so the network exists.
- Get the subnet CIDR:
   - `docker network inspect fg_next_default --format '{{(index .IPAM.Config 0).Subnet}}'`
- Set:
   - `FG_FORWARDED_ALLOW_IPS=<that CIDR>` (example: `172.18.0.0/16`)
- If the network name differs, it’s usually `<project>_default`; discover via:
   - `docker network ls | grep _default`



## Strict deterministic mode

This stack is designed so that **the same inputs produce the same on-disk artifacts** (hashes, deltas, reports),
provided you run in the same environment and do not introduce new non-deterministic external signals.

Determinism is enforced by:

- Canonical JSON serialization (`sort_keys`, stable separators) everywhere hashes are computed.
- Hash-chained logs (`termite.events`, `mite_ecology.kg_deltas`, `mite_ecology.ingested_bundles`, `termite.llm_calls`, `termite.tool_runs`).
- Deterministic GNN embeddings and GAT attention scoring (no stochastic dropout/training steps in this repo).
- Deterministic memo-GA RNG (`xorshift64*`) seeded from stable hashes (context node + cycle).
- Conservative merge: `mite-ecology import-bundle` validates bundle policy/signature then validates each op against `schemas/kg_delta.json`.

**Important:** LLM output is treated as *exogenous* unless cached.
`mite-ecology llm-*` records prompt/context hashes and stores raw responses,
but any *live* LLM call can vary across runs unless you only replay cached responses.

## Quick start (monorepo)

```sh
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt

# init
./termite_fieldpack/bin/termite init
./mite_ecology/bin/mite-ecology init

# ingest something (termite)
./termite_fieldpack/bin/termite ingest ./termite_fieldpack/docs/field_ops.md

# seal + verify (termite)
./termite_fieldpack/bin/termite seal --label demo
./termite_fieldpack/bin/termite verify ./artifacts/bundles_out/*.zip

# import into mite_ecology + run deterministic extrusion
./mite_ecology/bin/mite-ecology import-bundle ./artifacts/bundles_out/*.zip --notes "demo import"
./mite_ecology/bin/mite-ecology auto-run --cycles 3
```

## Termite LLM runtime ownership

Termite can manage an OpenAI-compatible local server and becomes the **runtime identity owner**:

```sh
./termite_fieldpack/bin/termite llm start
./termite_fieldpack/bin/termite llm ping
./termite_fieldpack/bin/termite llm status --json
./termite_fieldpack/bin/termite llm chat --prompt "Emit a strict kg_delta.jsonl for ..."
./termite_fieldpack/bin/termite llm stop
```

For Termux usage, configure `termite_fieldpack/config/termite.yaml` with either:
- `provider: endpoint_only` (you launch the server), or
- `provider: llama_cpp_server|vllm` with `launch.command` enabled (Termite launches it).

---

## MEAP modes and review workflow (mite_ecology)

`mite-ecology import-bundle` can override the policy mode per import.

- `AUTO_MERGE` applies the KG delta immediately and records a hash-chained ingest event.
- `REVIEW_ONLY` stages the KG delta as `PENDING` for human approval.
- `QUARANTINE` stages the KG delta as `QUARANTINED` (explicitly separated from normal review).
- `KILL` refuses ingestion.

Commands:

```bash
# stage
./mite_ecology/bin/mite-ecology import-bundle ./termite_fieldpack/artifacts/bundles_out/demo*.zip --mode REVIEW_ONLY --actor "alice" --notes "needs review"

# inspect staged queue
./mite_ecology/bin/mite-ecology review-list --status PENDING

# approve / reject
./mite_ecology/bin/mite-ecology review-approve 123 --actor "alice" --notes "ok"
./mite_ecology/bin/mite-ecology review-reject  124 --actor "alice" --notes "no"

# verify deterministic replay integrity
./mite_ecology/bin/mite-ecology replay-verify
```

## End-to-end demo

From the monorepo root:

```bash
./run_demo.sh
```

On Windows (PowerShell):

```powershell
.\run_demo.ps1
```

The demo:

1. Initializes an isolated Termite runtime.
2. Ingests a few resources and seals a deterministic, signed bundle.
3. Verifies and replays the bundle (structural checks only).
4. Imports the bundle into mite_ecology in three ways:
   - `AUTO_MERGE`
   - `REVIEW_ONLY` (approved)
   - `QUARANTINE` (rejected)
5. Runs the deterministic pipeline and replay verification on the merged cases.

---

## Local UI (single page)

This repo includes an optional local UI that wraps the CLI commands (upload/ingest, bundle ops, ecology pipeline, graph explorer, logs).

On Windows (PowerShell):

```powershell
./run_ui.ps1
```

Then open:

```text
http://127.0.0.1:8787/
```



## Android (Termux)

See `TERMUX.md` for a Termux-native install and run flow (including scripts).
